const P=["nav","header:not(article header)","footer","aside",'[role="navigation"]','[role="banner"]','[role="contentinfo"]','[aria-modal="true"]',".cookie-banner",".cookie-consent",".cookie-notice","#onetrust-consent-sdk","#cookie-banner",".ad",".ads",".advertisement",".adsbygoogle",".social-share",".share-buttons",".comments","#comments",".sidebar",".newsletter-signup","script","style","noscript","iframe","svg"];function z(e){if(!e)return!1;const s=window.getComputedStyle(e);if(s.display==="none"||s.visibility==="hidden"||s.opacity==="0")return!1;const a=e.getBoundingClientRect();return a.width>0||a.height>0||e.getClientRects().length>0}function w(e){return e.replace(/[\r\n]+/g,`
`).replace(/[ \t]+/g," ").replace(/\n\s*\n/g,`

`).trim()}function M(e){if(!e)return 0;const s=e.match(/\b\w+\b/g);return s?s.length:0}function q(){const e=window.location.href.toLowerCase(),s=e.endsWith(".pdf")||e.includes(".pdf?")||e.includes("/pdf/"),a=!!document.querySelector('embed[type="application/pdf"], object[type="application/pdf"]'),l=!!document.querySelector("#viewer.pdfViewer, .pdfViewer");return s||a?l&&document.querySelectorAll(".textLayer").length>0?{isPdf:!0}:{isPdf:!0,warning:"Content extraction is limited for this native document viewer. Text inside embedded canvas/PDF plugins may not be fully readable by DOM scripts."}:{isPdf:!1}}function B(){const e=["article","main",'[role="main"]',"#content",".content",".post-content",".article-content",".documentation-content",".markdown-body","#mw-content-text",".wiki-content"];for(const s of e){const a=document.querySelector(s);if(a&&z(a)&&a.innerText.trim().length>200)return a}return document.body}function j(){const e=document.title.trim()||window.location.hostname,s=window.location.href,a=window.location.hostname,l=q(),c=B().cloneNode(!0);for(const o of P)c.querySelectorAll(o).forEach(i=>i.remove());const d=[];let m={id:"sec-intro",heading:"Overview",level:1,content:"",wordCount:0,subheadings:[]};const E=document.createTreeWalker(c,NodeFilter.SHOW_ELEMENT,null);let k=E.currentNode,f=[];const v=()=>{const o=w(f.join(`
`));o.length>30&&(m.content=o,m.wordCount=M(o),d.push({...m})),f=[]};for(;k=E.nextNode();){const o=k,i=o.tagName.toLowerCase();if(/^h[1-4]$/.test(i)){const t=w(o.innerText);if(t&&t.length<150){v();const r=parseInt(i[1],10);m={id:`sec-${d.length+1}`,heading:t,level:r,content:"",wordCount:0,subheadings:[]};continue}}if(i==="p"){const t=w(o.innerText);t&&t.length>20&&f.push(t);continue}if(i==="ul"||i==="ol"){const t=Array.from(o.querySelectorAll("li")).map(r=>w(r.innerText)).filter(r=>r.length>3).map(r=>`• ${r}`);t.length>0&&f.push(t.join(`
`));continue}if(i==="pre"){const t=w(o.innerText);t&&t.length>15&&f.push(`\`\`\`
${t}
\`\`\``);continue}if(i==="table"){const t=Array.from(o.querySelectorAll("tr"));if(t.length>0){const r=[];t.slice(0,20).forEach(A=>{const x=Array.from(A.querySelectorAll("th, td")).map(T=>w(T.textContent||""));x.length>0&&r.push(`| ${x.join(" | ")} |`)}),r.length>0&&f.push(r.join(`
`))}continue}}v();const g=w(c.innerText||document.body.innerText);d.length===0&&g.length>20&&d.push({id:"sec-1",heading:"Main Content",level:1,content:g,wordCount:M(g)});const L=d.reduce((o,i)=>o+i.wordCount,0)||M(g);return{metadata:{title:e,url:s,domain:a,fetchedAt:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),wordCount:L,sectionCount:d.length,headingCount:d.filter(o=>o.heading!=="Overview"&&o.heading!=="Main Content").length,isPdfOrDoc:l.isPdf,documentViewerWarning:l.warning},sections:d,cleanText:g,chunks:[]}}typeof chrome<"u"&&chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener((e,s,a)=>{if(e.action==="PING")return a({status:"ready"}),!0;if(e.action==="EXTRACT_PAGE"){try{const l=j();a({success:!0,data:l})}catch(l){a({success:!1,error:l.message||"Failed to extract page content."})}return!0}});function F(){if(document.getElementById("arjuna-sarthi-floating-root"))return;const e=document.createElement("div");e.id="arjuna-sarthi-floating-root",e.style.position="fixed",e.style.zIndex="2147483647",e.style.right="24px",e.style.bottom="32px",e.style.width="56px",e.style.height="56px",e.style.userSelect="none";const s=e.attachShadow({mode:"open"}),a=document.createElement("style");a.textContent=`
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
    .arjuna-badge-btn {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: #231E19;
      border: 1.5px solid #3D332A;
      box-shadow: 0 8px 24px rgba(26, 22, 19, 0.4);
      cursor: grab;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      transition: transform 0.15s ease, box-shadow 0.15s ease;
      touch-action: none;
    }
    .arjuna-badge-btn:hover {
      transform: scale(1.06);
      box-shadow: 0 10px 28px rgba(181, 144, 106, 0.35);
    }
    .arjuna-badge-btn:active {
      cursor: grabbing;
      transform: scale(0.96);
    }
    .status-dot {
      position: absolute;
      bottom: 2px;
      right: 2px;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #4E9A75;
      border: 2px solid #231E19;
    }
    /* Companion Popup Panel */
    .arjuna-panel {
      position: fixed;
      bottom: 96px;
      right: 24px;
      width: 360px;
      max-height: 540px;
      background: #1A1613;
      color: #F2EDE5;
      border: 1.5px solid #3D332A;
      border-radius: 20px;
      box-shadow: 0 16px 48px rgba(0, 0, 0, 0.6);
      display: none;
      flex-direction: column;
      overflow: hidden;
      z-index: 2147483646;
    }
    .arjuna-panel.open {
      display: flex;
      animation: fadeIn 0.18s ease-out forwards;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .panel-header {
      padding: 12px 16px;
      background: #231E19;
      border-bottom: 1px solid #3D332A;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .panel-title {
      font-size: 13px;
      font-weight: 700;
      color: #F2EDE5;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .panel-close {
      background: none;
      border: none;
      color: #8E7F72;
      font-size: 18px;
      cursor: pointer;
      padding: 4px;
      line-height: 1;
      border-radius: 6px;
    }
    .panel-close:hover {
      color: #F2EDE5;
      background: #3D332A;
    }
    .panel-body {
      padding: 14px;
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 10px;
      font-size: 12px;
      line-height: 1.5;
      color: #C7B9AC;
    }
    .action-btn {
      background: #B5906A;
      color: #1A1613;
      font-weight: 700;
      padding: 9px 14px;
      border-radius: 12px;
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      font-size: 12px;
      transition: background 0.15s;
    }
    .action-btn:hover { background: #D9C2AA; }
    .chat-input-row {
      padding: 10px;
      background: #231E19;
      border-top: 1px solid #3D332A;
      display: flex;
      gap: 8px;
    }
    .chat-input {
      flex: 1;
      background: #1A1613;
      border: 1px solid #3D332A;
      border-radius: 10px;
      color: #F2EDE5;
      padding: 8px 12px;
      font-size: 12px;
      outline: none;
    }
    .chat-input:focus { border-color: #B5906A; }
    .send-btn {
      background: #B5906A;
      border: none;
      color: #1A1613;
      padding: 0 14px;
      border-radius: 10px;
      font-weight: 700;
      font-size: 12px;
      cursor: pointer;
    }
    .citation-tag {
      background: #2D2620;
      border: 1px solid #3D332A;
      color: #B5906A;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 10px;
      display: inline-block;
    }
  `;const l=`
    <svg viewBox="0 0 120 120" width="38" height="38" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="b-bronze" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#D9C2AA" />
          <stop offset="100%" stop-color="#785A3C" />
        </linearGradient>
      </defs>
      <circle cx="60" cy="60" r="54" stroke="#728A9E" stroke-width="1.2" stroke-dasharray="3 3" opacity="0.6"/>
      <ellipse cx="60" cy="60" rx="44" ry="18" transform="rotate(25 60 60)" stroke="#A38465" stroke-width="1.3" opacity="0.75"/>
      <ellipse cx="60" cy="60" rx="30" ry="12" transform="rotate(-15 60 60)" stroke="url(#b-bronze)" stroke-width="1.5"/>
      <path d="M60 26 L32 90" stroke="url(#b-bronze)" stroke-width="8" stroke-linecap="round"/>
      <path d="M60 26 L88 90" stroke="url(#b-bronze)" stroke-width="8" stroke-linecap="round"/>
      <line x1="44" y1="67" x2="76" y2="67" stroke="#728A9E" stroke-width="5" stroke-linecap="round"/>
      <circle cx="60" cy="67" r="3.5" fill="#F2EDE5"/>
      <circle cx="60" cy="26" r="3.5" fill="#F2EDE5"/>
    </svg>
  `,h=document.createElement("div");h.className="arjuna-badge-btn",h.title="Arjuna Sarthi (Drag to move, click to open)",h.innerHTML=`${l}<div class="status-dot"></div>`;const c=document.createElement("div");c.className="arjuna-panel",c.innerHTML=`
    <div class="panel-header">
      <div class="panel-title">
        ${l}
        <span>Arjuna Sarthi AI</span>
      </div>
      <button class="panel-close" title="Close panel">&times;</button>
    </div>
    <div class="panel-body">
      <div style="background: #231E19; padding: 10px; border-radius: 10px; border: 1px solid #3D332A;">
        <span style="color: #B5906A; font-weight: 600;">Active Page Companion</span>
        <p style="margin-top: 4px; font-size: 11px;">Extract and query this webpage with grounded AI intelligence.</p>
      </div>
      <button class="action-btn" id="fetch-page-btn">
        <span>⚡ Fetch Page Content</span>
      </button>
      <div id="panel-chat-messages" style="display: flex; flex-direction: column; gap: 8px;"></div>
    </div>
    <div class="chat-input-row">
      <input type="text" class="chat-input" id="panel-input" placeholder="Ask anything about this page..." />
      <button class="send-btn" id="panel-send">Ask</button>
    </div>
  `,s.appendChild(a),s.appendChild(c),s.appendChild(h),document.body.appendChild(e);let d=!1,m=0,E=0,k=0,f=0,v=!1;const g=(n,y)=>{d=!0,v=!1,m=n,E=y;const p=e.getBoundingClientRect();k=p.left,f=p.top},L=(n,y)=>{if(!d)return;const p=n-m,C=y-E;Math.hypot(p,C)>5&&(v=!0);const b=Math.min(Math.max(10,k+p),window.innerWidth-66),u=Math.min(Math.max(10,f+C),window.innerHeight-66);e.style.left=`${b}px`,e.style.top=`${u}px`,e.style.right="auto",e.style.bottom="auto"},S=()=>{d=!1};h.addEventListener("mousedown",n=>g(n.clientX,n.clientY)),window.addEventListener("mousemove",n=>L(n.clientX,n.clientY)),window.addEventListener("mouseup",S),h.addEventListener("touchstart",n=>{n.touches[0]&&g(n.touches[0].clientX,n.touches[0].clientY)}),window.addEventListener("touchmove",n=>{n.touches[0]&&L(n.touches[0].clientX,n.touches[0].clientY)}),window.addEventListener("touchend",S),h.addEventListener("click",()=>{v||c.classList.toggle("open")});const o=c.querySelector(".panel-close");o==null||o.addEventListener("click",()=>{c.classList.remove("open")});const i=c.querySelector("#fetch-page-btn"),t=c.querySelector("#panel-chat-messages"),r=c.querySelector("#panel-input"),A=c.querySelector("#panel-send");let x=null;i==null||i.addEventListener("click",()=>{try{x=j(),i.innerHTML=`<span>✓ Fetched (${x.sections.length} sections)</span>`,i.style.background="#2C7A53",i.style.color="#FFFFFF"}catch{i.innerHTML="<span>Error fetching</span>"}});const T=async()=>{var C;const n=(C=r==null?void 0:r.value)==null?void 0:C.trim();if(!n)return;r.value="";const y=document.createElement("div");y.style.cssText="background: #2D2620; padding: 8px 10px; border-radius: 10px; align-self: flex-end; color: #F2EDE5;",y.textContent=n,t==null||t.appendChild(y);const p=document.createElement("div");p.style.cssText="background: #231E19; padding: 8px 10px; border-radius: 10px; align-self: flex-start; color: #B5906A; font-style: italic;",p.textContent="Reasoning with AI...",t==null||t.appendChild(p);try{x||(x=j());const b=await fetch("http://localhost:8000/api/extension/ask",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:window.location.href,title:document.title,question:n,context:x.sections.slice(0,4).map(u=>({id:u.id,heading:u.heading,content:u.content.slice(0,1e3),url:window.location.href})),conversation:[]})});if(p.remove(),b.ok){const u=await b.json(),D=document.createElement("div");D.style.cssText="background: #231E19; border: 1px solid #3D332A; padding: 10px; border-radius: 10px; align-self: flex-start; color: #F2EDE5; line-height: 1.5;",D.innerHTML=`<div style="font-weight: 700; color: #B5906A; margin-bottom: 4px;">Arjuna Sarthi</div><div>${u.answer}</div>`,t==null||t.appendChild(D)}else{const u=document.createElement("div");u.style.cssText="color: #DE5B5B; font-size: 11px;",u.textContent="Could not query AI backend (verify localhost:8000).",t==null||t.appendChild(u)}}catch{p.remove();const b=document.createElement("div");b.style.cssText="color: #DE5B5B; font-size: 11px;",b.textContent="Backend offline or connection error.",t==null||t.appendChild(b)}};A==null||A.addEventListener("click",T),r==null||r.addEventListener("keydown",n=>{n.key==="Enter"&&T()})}typeof window<"u"&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",F):F());
